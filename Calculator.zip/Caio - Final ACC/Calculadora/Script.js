function displaynum(num1) {
    const input = document.getElementById('text01');
    input.value += num1;
}

function apagar() {
    const input = document.getElementById('text01');
    const inputText = input.value;
    input.value = inputText.substring(0, inputText.length - 1);
}

function resetCalculadora() {
    const input = document.getElementById('text01');
    input.value = '';
}

function calcular() {
    const input = document.getElementById('text01');
    try {
        input.value = eval(input.value);
    } catch (e) {
        input.value = 'Erro';
    }
}

let temaEscuro = false;

function alternarTema() {
    const body = document.body;
    const main = document.querySelector('.main');
    const text01 = document.getElementById('text01');
    const buttons = document.querySelectorAll('.num');

    temaEscuro = !temaEscuro;
    if (temaEscuro) {
        body.classList.add('dark-theme');
        main.classList.add('dark-theme');
        text01.classList.add('dark-theme');
        buttons.forEach(btn => btn.classList.add('dark-theme'));
    } else {
        body.classList.remove('dark-theme');
        main.classList.remove('dark-theme');
        text01.classList.remove('dark-theme');
        buttons.forEach(btn => btn.classList.remove('dark-theme'));
    }
}
